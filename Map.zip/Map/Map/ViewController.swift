//
//  ViewController.swift
//  Map
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit // import kit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate { // AA bhulyan nai ho add karvanu
    
    @IBOutlet weak var mapView: MKMapView!
    
    var manager : CLLocationManager! // make variable
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // ******************* LIVE LOCATION (START) ***************
        
        
        //1. Core location variable
        self.manager = CLLocationManager()
        self.manager.delegate = self
        
        // 2. Tell ios how accurate you want the location to be
        self.manager.desiredAccuracy = kCLLocationAccuracyBest
        
        //3. Ask user for permission
        self.manager.requestAlwaysAuthorization()
        
        //4. Get user location
        self.manager.startUpdatingLocation()
        
        
        // UI
        self.mapView.delegate = self
        mapView.mapType = MKMapType.standard
        mapView.showsUserLocation = true
        
        
        // ******************* (END) ************************
        
        
        /*
         
         *********************** STATIC LOCATION (START) ******************
         
        //1. CORDINATE : SET THE POSTITION OF THE CENTER OF THE MAP
        
        //22.038918, 70.866373
        let coord = CLLocationCoordinate2DMake(22.038918, 70.866373) // set the cordinate
        
        
        //2. SPAN : SET THE ZOOM LEVEL OF MAP
        
        let span = MKCoordinateSpanMake(0.007, 0.007) //set zoom level // small number zoom in  large number zoom out
        
        //3. REGION : CREATE A "REGION" OBJECT FOR THE MAP
        
        let region = MKCoordinateRegionMake(coord, span)
        
        // NONSENSE
        
        mapView.setRegion(region, animated: true)
        
         ******************************* (END) ********************************
         
         
        */
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // *************** LAST LOCATION *********************
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        //1. Logic : Recent location
        
        let i = locations.count - 1
        print("\(locations[i])")
        
        //2. UI
        
        // Coordinate
        // let coord = CLLocationCoordinate2DMake(22.038918, 70.866373)
        let coord = mapView.userLocation.coordinate
        
        // Span
        let span = MKCoordinateSpanMake(0.007, 0.007)
        
        //Region
        let region = MKCoordinateRegionMake(coord, span)
        
        // UI
        self.mapView.setRegion(region, animated: true)
        
    }
    

}

