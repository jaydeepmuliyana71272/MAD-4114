//
//  ViewController.swift
//  UserDefault
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtNme: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let defaults = UserDefaults.standard
        defaults.set("Pritesh", forKey: "studentName");
        
        print(defaults.set(800.50, forKey: "hourlyRate"))
        
        let courseTaught = ["ios 101","android 101","java 101"]
        defaults.set(courseTaught, forKey: "courses")
        
        let student = ["name":"Jaydeep","id":"10","program":"MADT"]
        defaults.set(student, forKey: "student")
        
        let x = defaults.double(forKey: "hourlyRate")
        print(x)
        
        print("Is Pritesh Instructer?")
        print(defaults.bool(forKey: "isInstructor"))
        
        print("Full name?")
        let name = defaults.string(forKey: "studentName")
        print(name!)
        
        print("What does he teach?")
        let c = defaults.array(forKey: "courses") as! [String]
        print(c)
        
        print("Who is Student?")
        let d = defaults.dictionary(forKey: "student") as! Dictionary<String,String>
        print(d)
        
        
        //print(defaults.dictionaryRepresentation())
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

