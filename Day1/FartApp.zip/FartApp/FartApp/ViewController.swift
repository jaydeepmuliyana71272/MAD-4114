//
//  ViewController.swift
//  FartApp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    var audioPlayer : AVAudioPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func playFart(_ sender: UIButton) {
        print("wet Fart")
        
        if(sender.tag == 1){
            let url = Bundle.main.url(forResource: "fart-03", withExtension: "mp3")
            
            do{
                audioPlayer = try AVAudioPlayer(contentsOf: url!)
                audioPlayer?.play()
                
            }
            catch{
                print("Error while trying to play file")
            }
        }
        else if(sender.tag == 2){
            let url = Bundle.main.url(forResource: "fart-squeak-01", withExtension: "mp3")
            
            do{
                audioPlayer = try AVAudioPlayer(contentsOf: url!)
                audioPlayer?.play()
                
            }
            catch{
                print("Error while trying to play file")
            }
        }
    }
    @IBAction func playLenFart(_ sender: UIButton) {
        
        print("Lentils Fart")
        let url = Bundle.main.url(forResource: "fart-06", withExtension: "mp3")
        
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: url!)
            audioPlayer?.play()
            
        }
        catch{
            print("Error while trying to play file")
        }
        
    }
   
}

